"""
Módulo de Visualizaciones
Genera todas las visualizaciones requeridas por el laboratorio.
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import seaborn as sns
from collections import Counter
from sklearn.decomposition import PCA


# Paleta unificada
COLORS = {
    'OT': '#2196F3',
    'NT': '#F44336',
    'primary': '#3F51B5',
    'secondary': '#FF5722',
    'background': '#FAFAFA'
}

def _savefig(fig, path: str, dpi: int = 150) -> None:
    fig.savefig(path, dpi=dpi, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print(f"  Guardado: {path}")


class Visualizer:
    """Orquestador de visualizaciones del corpus bíblico."""

    def __init__(self, output_dir: str = "outputs"):
        self._output_dir = output_dir

    # ─────────────────────────────────────────────
    # 1. Distribución de longitud de versículos
    # ─────────────────────────────────────────────
    def plot_verse_length_distribution(self, df: pd.DataFrame) -> None:
        df = df.copy()
        df['word_count'] = df['text'].apply(lambda t: len(str(t).split()))

        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        fig.suptitle("Distribución de Longitud de Versículos", fontsize=15, fontweight='bold')

        for ax, group, color in zip(axes,
                                    ['Old Testament', 'New Testament'],
                                    [COLORS['OT'], COLORS['NT']]):
            data = df[df['testament'] == group]['word_count']
            ax.hist(data, bins=40, color=color, alpha=0.8, edgecolor='white')
            ax.axvline(data.mean(), color='black', linestyle='--', linewidth=1.5,
                       label=f'Media={data.mean():.1f}')
            ax.set_title(group, fontsize=12)
            ax.set_xlabel("Palabras por versículo")
            ax.set_ylabel("Frecuencia")
            ax.legend()

        plt.tight_layout()
        _savefig(fig, f"{self._output_dir}/01_verse_length_distribution.png")

    # ─────────────────────────────────────────────
    # 2. Cantidad de versículos por libro
    # ─────────────────────────────────────────────
    def plot_verses_per_book(self, df: pd.DataFrame) -> None:
        counts = df.groupby(['testament', 'book']).size().reset_index(name='count')
        ot = counts[counts['testament'] == 'Old Testament'].sort_values('count', ascending=True)
        nt = counts[counts['testament'] == 'New Testament'].sort_values('count', ascending=True)

        fig, axes = plt.subplots(1, 2, figsize=(16, 10))
        fig.suptitle("Cantidad de Versículos por Libro", fontsize=15, fontweight='bold')

        for ax, data, color, title in zip(
                axes, [ot, nt], [COLORS['OT'], COLORS['NT']],
                ['Antiguo Testamento', 'Nuevo Testamento']):
            bars = ax.barh(data['book'], data['count'], color=color, alpha=0.85, edgecolor='white')
            ax.set_title(title, fontsize=12, fontweight='bold')
            ax.set_xlabel("Número de versículos")
            for bar, val in zip(bars, data['count']):
                ax.text(bar.get_width() + 5, bar.get_y() + bar.get_height() / 2,
                        str(val), va='center', fontsize=7)

        plt.tight_layout()
        _savefig(fig, f"{self._output_dir}/02_verses_per_book.png")

    # ─────────────────────────────────────────────
    # 3. Top palabras más frecuentes
    # ─────────────────────────────────────────────
    def plot_top_words(self, word_freqs: Counter, top_n: int = 30) -> None:
        words, counts = zip(*word_freqs.most_common(top_n))

        fig, ax = plt.subplots(figsize=(14, 6))
        bars = ax.bar(range(top_n), counts, color=COLORS['primary'], alpha=0.85, edgecolor='white')
        ax.set_xticks(range(top_n))
        ax.set_xticklabels(words, rotation=45, ha='right', fontsize=9)
        ax.set_title(f"Top {top_n} palabras más frecuentes del corpus bíblico", fontsize=14, fontweight='bold')
        ax.set_ylabel("Frecuencia")
        ax.set_xlabel("Palabra")

        plt.tight_layout()
        _savefig(fig, f"{self._output_dir}/03_top_words.png")

    # ─────────────────────────────────────────────
    # 4. Heatmap de similitud entre libros (OBLIGATORIO)
    # ─────────────────────────────────────────────
    def plot_book_similarity_heatmap(self, df: pd.DataFrame, tfidf_matrix: np.ndarray) -> None:
        """
        Heatmap NxN donde N = número de libros.
        Cada libro es representado por el centroide de sus versículos en el espacio TF-IDF.
        """
        books = df['book'].tolist()
        unique_books = df['book'].unique().tolist()
        n_books = len(unique_books)

        # Construir centroides por libro
        book_vectors = {}
        for book in unique_books:
            mask = [b == book for b in books]
            idx = [i for i, m in enumerate(mask) if m]
            book_vectors[book] = tfidf_matrix[idx].mean(axis=0)

        # Calcular similitud del coseno (manual)
        matrix_cos = np.zeros((n_books, n_books))
        vecs = np.array([book_vectors[b] for b in unique_books])
        norms = np.linalg.norm(vecs, axis=1, keepdims=True)
        norms[norms == 0] = 1
        vecs_norm = vecs / norms
        matrix_cos = vecs_norm @ vecs_norm.T

        # Separar AT y NT para resaltar en el eje
        ot_books = [b for b in unique_books if df[df['book'] == b]['testament'].iloc[0] == 'Old Testament']
        nt_books = [b for b in unique_books if df[df['book'] == b]['testament'].iloc[0] == 'New Testament']
        ordered_books = ot_books + nt_books

        # Reordenar
        idx_map = {b: i for i, b in enumerate(unique_books)}
        new_order = [idx_map[b] for b in ordered_books]
        matrix_reordered = matrix_cos[np.ix_(new_order, new_order)]

        fig, ax = plt.subplots(figsize=(22, 18))
        cmap = sns.color_palette("YlOrRd", as_cmap=True)
        im = ax.imshow(matrix_reordered, cmap=cmap, vmin=0, vmax=1, aspect='auto')

        ax.set_xticks(range(n_books))
        ax.set_yticks(range(n_books))
        ax.set_xticklabels(ordered_books, rotation=90, fontsize=6.5)
        ax.set_yticklabels(ordered_books, fontsize=6.5)
        ax.set_title("Heatmap de Similitud del Coseno entre Libros Bíblicos\n"
                     "(Columnas/Filas 1-39: Antiguo Testamento | 40-66: Nuevo Testamento)",
                     fontsize=13, fontweight='bold', pad=15)

        plt.colorbar(im, ax=ax, label="Similitud del Coseno", shrink=0.6)

        # Línea divisora AT/NT
        divider = len(ot_books) - 0.5
        ax.axhline(y=divider, color='navy', linewidth=2, linestyle='--', alpha=0.7)
        ax.axvline(x=divider, color='navy', linewidth=2, linestyle='--', alpha=0.7)
        ax.text(divider / 2, -3.5, "Antiguo Testamento", ha='center', fontsize=9,
                color='navy', fontweight='bold')
        ax.text(divider + (n_books - divider) / 2, -3.5, "Nuevo Testamento",
                ha='center', fontsize=9, color='darkred', fontweight='bold')

        plt.tight_layout()
        _savefig(fig, f"{self._output_dir}/04_book_similarity_heatmap.png", dpi=120)

    # ─────────────────────────────────────────────
    # 5. PCA de versículos
    # ─────────────────────────────────────────────
    def plot_pca_verses(self, df: pd.DataFrame, tfidf_matrix: np.ndarray,
                        max_verses: int = 5000) -> None:
        """
        Visualización 2D de versículos usando PCA.
        Usa una muestra si el dataset es muy grande.
        """
        n = min(max_verses, len(df))
        idx = np.random.choice(len(df), size=n, replace=False)
        X_sample = tfidf_matrix[idx]
        df_sample = df.iloc[idx].reset_index(drop=True)

        pca = PCA(n_components=2, random_state=42)
        coords = pca.fit_transform(X_sample)
        explained = pca.explained_variance_ratio_

        # Color por testamento
        testament_colors = {
            'Old Testament': COLORS['OT'],
            'New Testament': COLORS['NT']
        }

        fig, ax = plt.subplots(figsize=(13, 9))
        for testament, color in testament_colors.items():
            mask = df_sample['testament'] == testament
            ax.scatter(coords[mask, 0], coords[mask, 1],
                       c=color, alpha=0.35, s=4, label=testament, rasterized=True)

        ax.set_xlabel(f"PC1 ({explained[0]*100:.1f}% varianza explicada)", fontsize=11)
        ax.set_ylabel(f"PC2 ({explained[1]*100:.1f}% varianza explicada)", fontsize=11)
        ax.set_title(f"PCA de Versículos Bíblicos (muestra={n})\n"
                     f"Varianza total explicada: {(explained.sum()*100):.1f}%",
                     fontsize=13, fontweight='bold')
        ax.legend(markerscale=5, fontsize=11)
        ax.grid(alpha=0.3)

        plt.tight_layout()
        _savefig(fig, f"{self._output_dir}/05_pca_verses.png")

    # ─────────────────────────────────────────────
    # 6. Análisis de sentimiento
    # ─────────────────────────────────────────────
    def plot_sentiment_by_book(self, book_sentiment: pd.DataFrame) -> None:
        """Gráfico de barras del sentimiento promedio por libro."""
        ot = book_sentiment[book_sentiment['testament'] == 'Old Testament']
        nt = book_sentiment[book_sentiment['testament'] == 'New Testament']

        fig, axes = plt.subplots(2, 1, figsize=(18, 12))
        fig.suptitle("Sentimiento Promedio (Compound VADER) por Libro Bíblico",
                     fontsize=14, fontweight='bold')

        for ax, data, title in zip(axes, [ot, nt],
                                   ['Antiguo Testamento', 'Nuevo Testamento']):
            colors = [COLORS['NT'] if v < 0 else COLORS['OT'] for v in data['avg_compound']]
            ax.bar(range(len(data)), data['avg_compound'], color=colors, alpha=0.8, edgecolor='white')
            ax.set_xticks(range(len(data)))
            ax.set_xticklabels(data['book'], rotation=45, ha='right', fontsize=8)
            ax.axhline(y=0, color='black', linewidth=0.8, linestyle='--')
            ax.set_title(title, fontsize=11, fontweight='bold')
            ax.set_ylabel("Score Compound (VADER)")
            ax.set_ylim(-0.3, 0.5)

        plt.tight_layout()
        _savefig(fig, f"{self._output_dir}/06_sentiment_by_book.png")

    def plot_sentiment_evolution(self, df_with_sentiment: pd.DataFrame) -> None:
        """Evolución del sentimiento a lo largo de los capítulos del NT y AT."""
        # Ordenar capítulos con un índice global
        books_order = df_with_sentiment.drop_duplicates('book')[['testament', 'book']].reset_index(drop=True)

        fig, axes = plt.subplots(2, 1, figsize=(18, 10))
        fig.suptitle("Evolución del Sentimiento a lo largo del Corpus Bíblico",
                     fontsize=14, fontweight='bold')

        for ax, testament in zip(axes, ['Old Testament', 'New Testament']):
            data = df_with_sentiment[df_with_sentiment['testament'] == testament]
            books_in_t = data['book'].unique()
            x_pos = 0
            x_ticks, x_labels = [], []

            for book in books_in_t:
                chapters = data[data['book'] == book].groupby('chapter')['sent_compound'].mean()
                xs = list(range(x_pos, x_pos + len(chapters)))
                ax.plot(xs, chapters.values, alpha=0.7, linewidth=0.9,
                        color=COLORS['OT'] if testament == 'Old Testament' else COLORS['NT'])
                x_ticks.append(x_pos + len(chapters) // 2)
                x_labels.append(book)
                x_pos += len(chapters)

            ax.axhline(y=0, color='black', linewidth=0.5, linestyle='--')
            ax.set_xticks(x_ticks)
            ax.set_xticklabels(x_labels, rotation=45, ha='right', fontsize=7)
            ax.set_ylabel("Sentimiento Promedio")
            ax.set_title(f"{'Antiguo' if testament == 'Old Testament' else 'Nuevo'} Testamento")
            ax.fill_between(range(x_pos),
                            data.groupby(data.groupby('book').ngroup() * 200)['sent_compound'].mean().reindex(range(x_pos), method='nearest'),
                            0, alpha=0.1,
                            color=COLORS['OT'] if testament == 'Old Testament' else COLORS['NT'])

        plt.tight_layout()
        _savefig(fig, f"{self._output_dir}/07_sentiment_evolution.png")

    # ─────────────────────────────────────────────
    # 7. Comparación de modelos n-gram (perplejidad)
    # ─────────────────────────────────────────────
    def plot_ngram_comparison(self, perplexities: dict, generated_texts: dict) -> None:
        """Gráfico comparativo de perplejidad entre modelos n-gram."""
        models = list(perplexities.keys())
        values = [perplexities[m] for m in models]

        fig, ax = plt.subplots(figsize=(9, 5))
        bars = ax.bar(models, values, color=[COLORS['primary'], COLORS['secondary'],
                                             '#4CAF50', '#FF9800'], alpha=0.85,
                      edgecolor='white', width=0.5)
        ax.set_title("Perplejidad por Modelo N-gram\n(menor = mejor ajuste al corpus)",
                     fontsize=13, fontweight='bold')
        ax.set_ylabel("Perplejidad")
        ax.set_xlabel("Modelo")
        for bar, val in zip(bars, values):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5,
                    f'{val:.1f}', ha='center', fontsize=10, fontweight='bold')

        plt.tight_layout()
        _savefig(fig, f"{self._output_dir}/08_ngram_perplexity.png")

    # ─────────────────────────────────────────────
    # 8. Confusion matrix del clasificador
    # ─────────────────────────────────────────────
    def plot_confusion_matrix(self, cm: np.ndarray, labels: list, top_n: int = 20) -> None:
        """Matriz de confusión para los N libros más frecuentes en test."""
        # Tomar solo top_n para visibilidad
        cm_small = cm[:top_n, :top_n]
        labels_small = labels[:top_n]

        fig, ax = plt.subplots(figsize=(16, 14))
        sns.heatmap(cm_small, annot=True, fmt='d', cmap='Blues',
                    xticklabels=labels_small, yticklabels=labels_small,
                    ax=ax, linewidths=0.3, cbar_kws={'shrink': 0.6}, annot_kws={'size': 7})
        ax.set_title(f"Matriz de Confusión - Regresión Logística\n(Top {top_n} libros)",
                     fontsize=13, fontweight='bold')
        ax.set_xlabel("Predicho", fontsize=11)
        ax.set_ylabel("Real", fontsize=11)
        plt.xticks(rotation=45, ha='right', fontsize=8)
        plt.yticks(fontsize=8)
        plt.tight_layout()
        _savefig(fig, f"{self._output_dir}/09_confusion_matrix.png")

    # ─────────────────────────────────────────────
    # 9. Nube de palabras por testamento
    # ─────────────────────────────────────────────
    def plot_wordcloud(self, word_freqs_ot: Counter, word_freqs_nt: Counter) -> None:
        try:
            from wordcloud import WordCloud
        except ImportError:
            print("  wordcloud no disponible, saltando nube de palabras.")
            return

        fig, axes = plt.subplots(1, 2, figsize=(16, 7))
        fig.suptitle("Nubes de Palabras por Testamento", fontsize=14, fontweight='bold')

        for ax, freq, title, color in zip(
                axes,
                [word_freqs_ot, word_freqs_nt],
                ['Antiguo Testamento', 'Nuevo Testamento'],
                ['Blues', 'Reds']):
            wc = WordCloud(width=700, height=450, background_color='white',
                           colormap=color, max_words=120).generate_from_frequencies(freq)
            ax.imshow(wc, interpolation='bilinear')
            ax.axis('off')
            ax.set_title(title, fontsize=12, fontweight='bold')

        plt.tight_layout()
        _savefig(fig, f"{self._output_dir}/10_wordclouds.png")
