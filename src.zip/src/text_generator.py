"""
Modelos Generativos de Texto (N-gramas)
Implementa modelos estadísticos de lenguaje basados en frecuencias.
"""

import random
from collections import defaultdict, Counter
from typing import Optional
import pandas as pd


class NGramModel:
    """
    Modelo de lenguaje estadístico basado en n-gramas.
    Implementa unigram (n=1), bigram (n=2), trigram (n=3) y n-gram (n>=2).
    Incluye tokens especiales <START> y <END>.
    """

    START_TOKEN = "<START>"
    END_TOKEN = "<END>"

    def __init__(self, n: int = 2, seed: int = 42):
        if n < 1:
            raise ValueError("n debe ser >= 1")
        self.n = n
        self._seed = seed
        self._model = defaultdict(Counter)    # contexto -> Counter de palabras siguientes
        self._unigram_counts = Counter()
        self._total_unigrams = 0
        self._vocab = set()

    @property
    def model_name(self) -> str:
        names = {1: "Unigram", 2: "Bigram", 3: "Trigram"}
        return names.get(self.n, f"{self.n}-gram")

    def _make_context(self, tokens: list, i: int) -> tuple:
        """Construye el contexto (tupla de tokens previos) para predecir el token en posición i."""
        if self.n == 1:
            return ()
        start = max(0, i - (self.n - 1))
        return tuple(tokens[start:i])

    def train(self, tokenized_corpus: list) -> None:
        """
        Entrena el modelo sobre el corpus tokenizado.
        tokenized_corpus: lista de listas de tokens (una por versículo).
        """
        self._model = defaultdict(Counter)
        self._unigram_counts = Counter()

        for verse_tokens in tokenized_corpus:
            if not verse_tokens:
                continue

            # Construir secuencia con tokens especiales
            if self.n == 1:
                sequence = verse_tokens + [self.END_TOKEN]
            else:
                padding = [self.START_TOKEN] * (self.n - 1)
                sequence = padding + verse_tokens + [self.END_TOKEN]

            # Actualizar n-gramas
            for i in range(len(padding) if self.n > 1 else 0, len(sequence)):
                token = sequence[i]
                context = self._make_context(sequence, i)
                self._model[context][token] += 1
                if self.n == 1 or token not in (self.START_TOKEN,):
                    self._unigram_counts[token] += 1

            self._vocab.update(verse_tokens)

        self._total_unigrams = sum(self._unigram_counts.values())
        print(f"  Modelo {self.model_name} entrenado: {len(self._model)} contextos, {len(self._vocab)} palabras.")

    def _sample_next(self, context: tuple, temperature: float = 1.0) -> Optional[str]:
        """Muestrea la siguiente palabra dado el contexto."""
        if self.n == 1:
            # Unigram: muestrear por frecuencia global
            words = list(self._unigram_counts.keys())
            counts = np.array([self._unigram_counts[w] for w in words], dtype=float)
            if temperature != 1.0:
                counts = counts ** (1.0 / temperature)
            counts /= counts.sum()
            return random.choices(words, weights=counts)[0]

        if context not in self._model:
            # Backoff: reducir contexto
            if len(context) > 1:
                return self._sample_next(context[1:], temperature)
            else:
                # Unigram fallback
                words = list(self._unigram_counts.keys())
                counts = list(self._unigram_counts.values())
                return random.choices(words, weights=counts)[0]

        candidates = self._model[context]
        words = list(candidates.keys())
        counts = np.array([candidates[w] for w in words], dtype=float)
        if temperature != 1.0:
            counts = counts ** (1.0 / temperature)
        counts /= counts.sum()
        return random.choices(words, weights=counts)[0]

    def generate(self, seed_word: Optional[str] = None, max_length: int = 30,
                 temperature: float = 1.0) -> str:
        """
        Genera una secuencia de texto.

        Parámetros:
            seed_word: palabra inicial (si None, se escoge aleatoriamente)
            max_length: longitud máxima de la secuencia generada
            temperature: controla aleatoriedad (>1 más variado, <1 más determinista)

        Retorna: texto generado como string
        """
        random.seed(self._seed)
        import numpy as np

        # Elegir palabra inicial
        if seed_word is None or seed_word not in self._vocab:
            seed_word = random.choice(list(self._vocab))

        if self.n == 1:
            generated = [seed_word]
            for _ in range(max_length - 1):
                next_word = self._sample_next((), temperature)
                if next_word == self.END_TOKEN:
                    break
                generated.append(next_word)
        else:
            padding = [self.START_TOKEN] * (self.n - 1)
            # Insertar seed_word en la secuencia
            sequence = padding + [seed_word]
            generated = [seed_word]

            for _ in range(max_length - 1):
                context = tuple(sequence[-(self.n - 1):])
                next_word = self._sample_next(context, temperature)
                if next_word == self.END_TOKEN:
                    break
                generated.append(next_word)
                sequence.append(next_word)

        return ' '.join(generated)

    def perplexity(self, tokenized_test: list) -> float:
        """Calcula la perplejidad del modelo sobre un conjunto de prueba."""
        import numpy as np
        import math
        log_prob_sum = 0
        n_tokens = 0

        for verse_tokens in tokenized_test:
            if not verse_tokens:
                continue
            if self.n > 1:
                padding = [self.START_TOKEN] * (self.n - 1)
                sequence = padding + verse_tokens + [self.END_TOKEN]
            else:
                sequence = verse_tokens + [self.END_TOKEN]

            for i in range(len(padding) if self.n > 1 else 0, len(sequence)):
                token = sequence[i]
                context = self._make_context(sequence, i)
                if self.n == 1:
                    prob = self._unigram_counts.get(token, 1) / max(self._total_unigrams, 1)
                else:
                    if context in self._model and self._model[context]:
                        total = sum(self._model[context].values())
                        prob = (self._model[context].get(token, 0) + 1) / (total + len(self._vocab))
                    else:
                        prob = 1.0 / max(len(self._vocab), 1)

                log_prob_sum += math.log(max(prob, 1e-10))
                n_tokens += 1

        if n_tokens == 0:
            return float('inf')
        return math.exp(-log_prob_sum / n_tokens)


import numpy as np  # needed for _sample_next


class TextGenerator:
    """
    Orquestador de modelos de generación de texto.
    Gestiona modelos unigram, bigram, trigram y n-gram personalizado.
    """

    def __init__(self):
        self._models = {}

    def train_all(self, tokenized_corpus: list, custom_n: int = 4) -> None:
        """Entrena todos los modelos (1, 2, 3 y custom_n)."""
        for n in [1, 2, 3, custom_n]:
            name = {1: 'unigram', 2: 'bigram', 3: 'trigram'}.get(n, f'{n}gram')
            print(f"Entrenando {name}...")
            model = NGramModel(n=n)
            model.train(tokenized_corpus)
            self._models[name] = model

    def generate_with_all(self, seed_word: Optional[str] = None,
                          max_length: int = 20, temperature: float = 1.0) -> dict:
        """
        Genera texto con todos los modelos disponibles.
        Retorna diccionario {nombre_modelo: texto_generado}.
        """
        results = {}
        for name, model in self._models.items():
            text = model.generate(seed_word=seed_word, max_length=max_length,
                                  temperature=temperature)
            results[name] = text
        return results

    @property
    def models(self) -> dict:
        return self._models
