"""
Clasificador de Versículos
Predice el libro bíblico al que pertenece un versículo.
Usa Naive Bayes Multinomial y Regresión Logística.
"""

import numpy as np
import pandas as pd
from collections import defaultdict, Counter
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from src.preprocessor import TextPreprocessor, TFIDFVectorizer


class NaiveBayesClassifier:
    """Implementación manual de Naive Bayes Multinomial."""

    def __init__(self, alpha: float = 1.0):
        self.alpha = alpha  # suavizado de Laplace
        self._class_log_priors = {}
        self._feature_log_probs = {}
        self._classes = []
        self._n_features = 0

    def fit(self, X: np.ndarray, y: np.ndarray) -> "NaiveBayesClassifier":
        self._classes = list(set(y))
        self._n_features = X.shape[1]
        n_samples = len(y)

        for cls in self._classes:
            mask = (y == cls)
            class_docs = X[mask]
            self._class_log_priors[cls] = np.log(mask.sum() / n_samples)
            # Suma de features por clase + suavizado Laplace
            feature_counts = class_docs.sum(axis=0) + self.alpha
            total = feature_counts.sum()
            self._feature_log_probs[cls] = np.log(feature_counts / total)

        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        preds = []
        for x in X:
            scores = {}
            for cls in self._classes:
                scores[cls] = self._class_log_priors[cls] + np.dot(x, self._feature_log_probs[cls])
            preds.append(max(scores, key=scores.get))
        return np.array(preds)

    def predict_proba(self, X: np.ndarray) -> tuple:
        """Retorna (predicciones, probabilidades normalizadas)."""
        all_scores = []
        for x in X:
            scores = {}
            for cls in self._classes:
                scores[cls] = self._class_log_priors[cls] + np.dot(x, self._feature_log_probs[cls])
            all_scores.append(scores)
        return all_scores


class VerseClassifier:
    """
    Sistema de clasificación de versículos.
    Entrena modelos para predecir el libro al que pertenece un versículo.
    """

    def __init__(self, preprocessor: TextPreprocessor, vectorizer: TFIDFVectorizer):
        self._preprocessor = preprocessor
        self._vectorizer = vectorizer
        self._logistic = LogisticRegression(max_iter=1000, C=1.0, solver='lbfgs',
                                            random_state=42)
        self._naive_bayes = None
        self._label_encoder = {}
        self._label_decoder = {}
        self._X_train = None
        self._X_test = None
        self._y_train = None
        self._y_test = None
        self._results = {}

    def prepare_data(self, df: pd.DataFrame, tfidf_matrix: np.ndarray,
                     test_size: float = 0.2, random_state: int = 42) -> None:
        """
        Prepara los datos para entrenamiento y prueba.
        Filtra libros con al menos 50 versículos para tener suficientes muestras.
        """
        book_counts = df['book'].value_counts()
        valid_books = book_counts[book_counts >= 50].index.tolist()
        mask = df['book'].isin(valid_books)

        X = tfidf_matrix[mask.values]
        y_labels = df[mask]['book'].values

        # Codificar etiquetas
        unique_labels = sorted(set(y_labels))
        self._label_encoder = {label: i for i, label in enumerate(unique_labels)}
        self._label_decoder = {i: label for label, i in self._label_encoder.items()}
        y = np.array([self._label_encoder[label] for label in y_labels])

        self._X_train, self._X_test, self._y_train, self._y_test = train_test_split(
            X, y, test_size=test_size, random_state=random_state, stratify=y
        )
        print(f"  Libros clasificables: {len(unique_labels)}")
        print(f"  Train: {len(self._X_train)} | Test: {len(self._X_test)}")

    def train_logistic(self) -> dict:
        """Entrena Regresión Logística y retorna métricas."""
        print("  Entrenando Regresión Logística...")
        self._logistic.fit(self._X_train, self._y_train)
        y_pred = self._logistic.predict(self._X_test)
        acc = accuracy_score(self._y_test, y_pred)
        cm = confusion_matrix(self._y_test, y_pred)
        report = classification_report(
            self._y_test, y_pred,
            target_names=[self._label_decoder[i] for i in range(len(self._label_decoder))],
            output_dict=True, zero_division=0
        )
        self._results['logistic'] = {
            'accuracy': acc,
            'confusion_matrix': cm,
            'report': report,
            'y_pred': y_pred
        }
        print(f"  Accuracy Logística: {acc:.4f}")
        return self._results['logistic']

    def predict_verse(self, text: str, model: str = 'logistic') -> dict:
        """Predice el libro de un versículo dado."""
        tokens = self._preprocessor.preprocess(text)
        vec = np.zeros(len(self._vectorizer.vocabulary), dtype=np.float32)
        from collections import Counter
        tf = Counter(tokens)
        total = len(tokens) if tokens else 1
        for word, count in tf.items():
            if word in self._vectorizer.vocabulary:
                j = self._vectorizer.vocabulary[word]
                vec[j] = (count / total) * self._vectorizer.idf_values.get(word, 0)
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec /= norm

        if model == 'logistic':
            pred_idx = self._logistic.predict([vec])[0]
            proba = self._logistic.predict_proba([vec])[0]
            top3 = np.argsort(proba)[::-1][:3]
            return {
                'predicted_book': self._label_decoder[pred_idx],
                'confidence': float(proba[pred_idx]),
                'top3': [(self._label_decoder[i], float(proba[i])) for i in top3]
            }

    @property
    def results(self) -> dict:
        return self._results

    @property
    def label_decoder(self) -> dict:
        return self._label_decoder

    @property
    def y_test(self) -> np.ndarray:
        return self._y_test
