"""
Análisis de Sentimiento sobre el Corpus Bíblico
Utiliza VADER (Valence Aware Dictionary and Sentiment Reasoner).
"""

import pandas as pd
import numpy as np
from nltk.sentiment import SentimentIntensityAnalyzer


class SentimentAnalyzer:
    """
    Analiza el sentimiento de versículos usando VADER.
    VADER es apropiado para texto en inglés y analiza polaridad positiva, negativa y neutral.
    """

    def __init__(self):
        self._sia = SentimentIntensityAnalyzer()

    def score_verse(self, text: str) -> dict:
        """
        Analiza un versículo individual.
        Retorna diccionario con scores: neg, neu, pos, compound.
        """
        scores = self._sia.polarity_scores(str(text))
        return scores

    def analyze_corpus(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Analiza todo el corpus y agrega columnas de sentimiento.
        Retorna DataFrame con columnas adicionales: sent_neg, sent_neu, sent_pos, sent_compound.
        """
        results = df['text'].apply(lambda t: self._sia.polarity_scores(str(t)))
        df = df.copy()
        df['sent_neg']      = results.apply(lambda x: x['neg'])
        df['sent_neu']      = results.apply(lambda x: x['neu'])
        df['sent_pos']      = results.apply(lambda x: x['pos'])
        df['sent_compound'] = results.apply(lambda x: x['compound'])
        return df

    def aggregate_by_book(self, df_with_sentiment: pd.DataFrame) -> pd.DataFrame:
        """Agrega puntajes de sentimiento por libro."""
        agg = df_with_sentiment.groupby('book').agg(
            testament=('testament', 'first'),
            avg_compound=('sent_compound', 'mean'),
            avg_pos=('sent_pos', 'mean'),
            avg_neg=('sent_neg', 'mean'),
            avg_neu=('sent_neu', 'mean'),
            n_verses=('text', 'count'),
            n_positive=('sent_compound', lambda x: (x > 0.05).sum()),
            n_negative=('sent_compound', lambda x: (x < -0.05).sum()),
            n_neutral=('sent_compound', lambda x: ((x >= -0.05) & (x <= 0.05)).sum())
        ).reset_index()
        return agg

    def aggregate_by_chapter(self, df_with_sentiment: pd.DataFrame) -> pd.DataFrame:
        """Agrega puntajes de sentimiento por libro+capítulo."""
        agg = df_with_sentiment.groupby(['book', 'chapter']).agg(
            testament=('testament', 'first'),
            avg_compound=('sent_compound', 'mean'),
            avg_pos=('sent_pos', 'mean'),
            avg_neg=('sent_neg', 'mean'),
            n_verses=('text', 'count')
        ).reset_index()
        return agg

    def get_extreme_books(self, book_sentiment: pd.DataFrame, top_n: int = 5) -> dict:
        """
        Identifica los libros con sentimientos más extremos.
        Retorna diccionario con top positivos, negativos y más neutros.
        """
        most_positive  = book_sentiment.nlargest(top_n, 'avg_compound')[['book', 'avg_compound', 'testament']]
        most_negative  = book_sentiment.nsmallest(top_n, 'avg_compound')[['book', 'avg_compound', 'testament']]
        most_neutral   = book_sentiment.nsmallest(top_n, 'avg_pos')[['book', 'avg_pos', 'testament']]
        return {
            'most_positive': most_positive,
            'most_negative': most_negative,
            'most_neutral':  most_neutral
        }
