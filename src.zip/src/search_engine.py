"""
Motor de Búsqueda Semántico
Implementa similitud del coseno manualmente para encontrar versículos similares.
"""

import numpy as np
import pandas as pd
from src.preprocessor import TextPreprocessor, TFIDFVectorizer


class CosineSimilarity:
    """Cálculo manual de similitud del coseno."""

    @staticmethod
    def compute(vec_a: np.ndarray, vec_b: np.ndarray) -> float:
        """Similitud del coseno entre dos vectores."""
        norm_a = np.linalg.norm(vec_a)
        norm_b = np.linalg.norm(vec_b)
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return float(np.dot(vec_a, vec_b) / (norm_a * norm_b))

    @staticmethod
    def compute_batch(query_vec: np.ndarray, matrix: np.ndarray) -> np.ndarray:
        """
        Similitud del coseno entre un vector query y una matriz de documentos.
        Las filas de la matriz ya deben estar L2-normalizadas.
        """
        q_norm = np.linalg.norm(query_vec)
        if q_norm == 0:
            return np.zeros(matrix.shape[0])
        query_normalized = query_vec / q_norm
        return matrix @ query_normalized


class SemanticSearchEngine:
    """
    Motor de búsqueda semántico basado en TF-IDF + similitud del coseno.
    Permite buscar los K versículos más similares a una consulta.
    """

    def __init__(self, preprocessor: TextPreprocessor, vectorizer: TFIDFVectorizer):
        self._preprocessor = preprocessor
        self._vectorizer = vectorizer
        self._tfidf_matrix: np.ndarray = None
        self._df: pd.DataFrame = None

    def index(self, df: pd.DataFrame, tfidf_matrix: np.ndarray) -> None:
        """
        Indexa el corpus.
        df: DataFrame con columnas [testament, book, chapter, verse, text]
        tfidf_matrix: matriz TF-IDF precalculada (N x V)
        """
        self._df = df.reset_index(drop=True)
        self._tfidf_matrix = tfidf_matrix

    def _vectorize_query(self, query: str) -> np.ndarray:
        """Convierte una consulta de texto al espacio TF-IDF."""
        tokens = self._preprocessor.preprocess(query)
        vec = np.zeros(len(self._vectorizer.vocabulary), dtype=np.float32)
        if tokens:
            from collections import Counter
            import math
            tf = Counter(tokens)
            total = len(tokens)
            for word, count in tf.items():
                if word in self._vectorizer.vocabulary:
                    j = self._vectorizer.vocabulary[word]
                    tf_val = count / total
                    idf_val = self._vectorizer.idf_values.get(word, 0)
                    vec[j] = tf_val * idf_val
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec /= norm
        return vec

    def search(self, query: str, k: int = 5, exclude_exact: bool = True) -> pd.DataFrame:
        """
        Busca los K versículos más similares a la consulta.

        Parámetros:
            query: texto de consulta o versículo
            k: número de resultados a retornar
            exclude_exact: si True, excluye versículos idénticos al query

        Retorna:
            DataFrame con columnas [rank, book, chapter, verse, text, similarity]
        """
        if self._tfidf_matrix is None:
            raise RuntimeError("Debe indexar el corpus antes de buscar. Llame a index().")

        query_vec = self._vectorize_query(query)
        similarities = CosineSimilarity.compute_batch(query_vec, self._tfidf_matrix)

        if exclude_exact:
            # Excluir versículos cuyo texto sea casi idéntico al query
            indices = np.argsort(similarities)[::-1]
            results = []
            for idx in indices:
                verse_text = self._df.iloc[idx]['text']
                if verse_text.strip().lower() != query.strip().lower():
                    results.append(idx)
                if len(results) >= k:
                    break
        else:
            results = np.argsort(similarities)[::-1][:k].tolist()

        rows = []
        for rank, idx in enumerate(results, 1):
            row = self._df.iloc[idx]
            rows.append({
                'rank': rank,
                'book': row['book'],
                'chapter': row['chapter'],
                'verse': row['verse'],
                'text': row['text'],
                'similarity': round(float(similarities[idx]), 4)
            })

        return pd.DataFrame(rows)
