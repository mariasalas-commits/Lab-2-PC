"""
Módulo de Preprocesamiento Textual
Implementa pipeline completo para el corpus bíblico.
"""

import re
import math
import string
import pandas as pd
import numpy as np
from collections import Counter, defaultdict
from nltk.corpus import stopwords


class TextPreprocessor:
    """
    Pipeline de preprocesamiento textual para corpus bíblico.
    Incluye tokenización, limpieza, eliminación de stopwords y construcción de vocabulario.
    """

    def __init__(self, language: str = "english", extra_stopwords: list = None):
        self.language = language
        self._stop_words = set(stopwords.words(language))
        if extra_stopwords:
            self._stop_words.update(extra_stopwords)
        self._vocabulary = {}
        self._word_frequencies = Counter()

    @property
    def vocabulary(self) -> dict:
        return self._vocabulary

    @property
    def word_frequencies(self) -> Counter:
        return self._word_frequencies

    def clean_text(self, text: str) -> str:
        """Convierte a minúsculas y elimina puntuación, caracteres especiales y números."""
        text = text.lower()
        text = re.sub(r'\{[^}]*\}', ' ', text)       # elimina anotaciones entre llaves
        text = re.sub(r'[^a-z\s]', ' ', text)         # elimina puntuación, números y especiales
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    def tokenize(self, text: str) -> list:
        """Tokeniza el texto en palabras."""
        return text.split()

    def remove_stopwords(self, tokens: list) -> list:
        """Elimina palabras vacías."""
        return [t for t in tokens if t not in self._stop_words and len(t) > 1]

    def preprocess(self, text: str) -> list:
        """Pipeline completo: limpieza → tokenización → eliminación de stopwords."""
        cleaned = self.clean_text(text)
        tokens = self.tokenize(cleaned)
        tokens = self.remove_stopwords(tokens)
        return tokens

    def build_vocabulary_from_series(self, text_series: pd.Series) -> dict:
        """Construye el vocabulario y calcula frecuencias sobre un corpus."""
        self._word_frequencies = Counter()
        for text in text_series:
            tokens = self.preprocess(str(text))
            self._word_frequencies.update(tokens)
        # Ordenar por frecuencia
        sorted_words = sorted(self._word_frequencies, key=lambda w: self._word_frequencies[w], reverse=True)
        self._vocabulary = {word: idx for idx, word in enumerate(sorted_words)}
        return self._vocabulary

    def get_top_words(self, n: int = 30) -> list:
        """Retorna las N palabras más frecuentes del corpus."""
        return self._word_frequencies.most_common(n)


class TFIDFVectorizer:
    """
    Implementación manual de TF-IDF (sin sklearn).
    TF = frecuencia del término en el documento.
    IDF = log(N / df), donde N = total documentos, df = documentos con el término.
    """

    def __init__(self, max_features: int = 5000, min_df: int = 2):
        self.max_features = max_features
        self.min_df = min_df
        self._idf = {}
        self._vocab = {}
        self._n_docs = 0

    @property
    def vocabulary(self) -> dict:
        return self._vocab

    @property
    def idf_values(self) -> dict:
        return self._idf

    def _compute_tf(self, tokens: list) -> dict:
        """Calcula TF (frecuencia relativa de cada término en el documento)."""
        if not tokens:
            return {}
        count = Counter(tokens)
        total = len(tokens)
        return {word: freq / total for word, freq in count.items()}

    def fit(self, tokenized_docs: list) -> "TFIDFVectorizer":
        """
        Ajusta el vectorizador calculando IDF sobre la colección de documentos.
        tokenized_docs: lista de listas de tokens.
        """
        self._n_docs = len(tokenized_docs)
        df_count = Counter()

        for tokens in tokenized_docs:
            unique_tokens = set(tokens)
            for token in unique_tokens:
                df_count[token] += 1

        # Filtrar por min_df y seleccionar top features
        valid_words = {w: c for w, c in df_count.items() if c >= self.min_df}
        top_words = sorted(valid_words, key=lambda w: valid_words[w], reverse=True)[:self.max_features]

        self._vocab = {word: idx for idx, word in enumerate(top_words)}
        for word in top_words:
            self._idf[word] = math.log((1 + self._n_docs) / (1 + df_count[word])) + 1

        return self

    def transform(self, tokenized_docs: list) -> np.ndarray:
        """Transforma documentos a matriz TF-IDF sparse-like (ndarray)."""
        n_docs = len(tokenized_docs)
        n_terms = len(self._vocab)
        matrix = np.zeros((n_docs, n_terms), dtype=np.float32)

        for i, tokens in enumerate(tokenized_docs):
            tf = self._compute_tf(tokens)
            for word, tf_val in tf.items():
                if word in self._vocab:
                    j = self._vocab[word]
                    matrix[i, j] = tf_val * self._idf[word]

        # L2 normalization
        norms = np.linalg.norm(matrix, axis=1, keepdims=True)
        norms[norms == 0] = 1
        matrix /= norms

        return matrix

    def fit_transform(self, tokenized_docs: list) -> np.ndarray:
        """Ajusta y transforma en un solo paso."""
        return self.fit(tokenized_docs).transform(tokenized_docs)
